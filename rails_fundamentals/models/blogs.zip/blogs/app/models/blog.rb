class Blog < ActiveRecord::Base
    validates :name, :desc, presence:true
    has_many :posts, dependent: :destroy 
end
