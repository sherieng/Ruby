class DojosControllerController < ApplicationController
  def index
    @dojo = Dojo.all
  end
end
