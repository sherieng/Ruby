Rails.application.routes.draw do
  get 'dojos' => "dojos_controller#index"
end
