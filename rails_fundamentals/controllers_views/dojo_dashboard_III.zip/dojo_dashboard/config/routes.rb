Rails.application.routes.draw do
  get 'dojos' => "dojos_controller#index"
  get "dojos/new" => "dojos_controller#new"
  post "dojos" => "dojos_controller#create"
  get "dojos/:id" => "dojos_controller#show"
  get "dojos/:id/edit" => "dojos_controller#edit"
  patch "dojos/:id" => "dojos_controller#update"
  delete "dojos/:id" => "dojos_controller#destroy"
end
