Rails.application.routes.draw do
  get 'dojos' => "dojos_controller#index"
  get "dojos/new" => "dojos_controller#new"
  post "dojos/create" => "dojos_controller#create"
end
