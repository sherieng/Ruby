class DojosControllerController < ApplicationController
  def index
    @dojo = Dojo.all
  end

  def new
    @dojo = Dojo.new
  end 

  def create
    @dojo = Dojo.new(dojo_params)
    if @dojo.valid?
      puts "in if affirm statement"
      @dojo.save
      flash[:success] = "You have successfully added a dojo."
      redirect_to '/dojos/new'
    else
      flash[:error] = @dojo.errors.full_messages
      puts "in if error statement"
      redirect_to "/dojos/new"      
    end
  end 

  private 
    def dojo_params
      params.require(:dojo).permit(:branch, :street, :city, :state)
    end
end
